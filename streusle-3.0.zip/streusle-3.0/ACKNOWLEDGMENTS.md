Organizer and lead schemer/sometimes annotator: Nathan Schneider

MWE annotation schemers; MWE, noun supersense, and verb supersense annotators:

* Spencer Onuffer
* Nora Kazour
* Henrietta Conrad
* Emily Danchik
* Michael T. Mordowanec

Preposition supersense annotation schemers:

* Jena Hwang
* Vivek Srikumar
* Martha Palmer
* Katie Conger
* Tim O'Gorman
* Meredith Green
* Abhijit Suresh

Preposition supersense annotators (University of Colorado):

* Meredith Green (lead)
* Evan Coles-Harris
* Audrey Farber
* Nicole Gordiyenko
* Megan Hutto
* Celeste Smitz
* Tim Watervoort

Preposition supersense pilot annotators (Carnegie Mellon University):

* Archna Bhatia
* Carlos Ramírez
* Yulia Tsvetkov
* Michael T. Mordowanec
* Matt Gardner
* Spencer Onuffer
* Nora Kazour

PrepWiki tech guru

* Michael T. Mordowanec

Special thanks

* Noah Smith
* Mark Steedman
* Claire Bonial
* Tim Baldwin
* Chris Dyer
* Ed Hovy
* Lingpeng Kong
* Lori Levin
* Ken Litkowski
* Orin Hargraves
* Susan Brown
* Michael Ellsworth
* Dipanjan Das

This research was supported in part by:

* NSF CAREER grant IIS-1054319
* DARPA grant FA8750-12-2-0342 funded under the DEFT program
* a Google Research Award for Q/A PropBank annotation
